/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckInDonate;

/**
 *
 * @author Chuimin
 */
public class StoreData {
    public static void main(String[] args) {
        
        Cust1 CustomerFrame = new Cust1();
        CustomerFrame.setVisible(true);
        CustomerFrame.pack();
        CustomerFrame.setLocationRelativeTo(null);
        
        
    }
}
