/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pos1;

/**
 *
 * @author Chuimin
 */
public class Pos1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        home homeFrame = new home();
        homeFrame.setVisible(true);
        homeFrame.pack();
        homeFrame.setLocationRelativeTo(null); 
    }
    
}
