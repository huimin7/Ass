/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pos1;

/**
 *
 * @author Chuimin
 */
import java.sql.Connection;
import java.sql.*;

public class db {
    public static Connection mycon(){
        
        Connection con = null;
        
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jbdc:mysq://localhost/pos","root","");
            return con;
            
        }catch(Exception e){
            System.out.println(e);
            return null;
        }
        
        
    }
}
