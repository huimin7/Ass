/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckInandDonate;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;


/**
 *
 * @author Chuimin
 */
public class Donate {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Username: ");
        String user=sc.nextLine();
        
        donate(user);
    }
    
    public static void donate(String username){
        
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the amount to donate: ");
        double amt=sc.nextDouble();
        sc.nextLine();
        System.out.println("=======================================");
        System.out.println("Global Environment Centre (GEC)\n" +"Malaysia Nature Society (MNS)\n" +"Sabah Wetlands Conservation Society (SWCS)\n" +"TRAFFIC\n" +"World Wide Fund for Nature (WWF) Malaysia\n" +"Water Watch Penang (WWP)\n" +"Sahabat Alam Malaysia (SAM)\n" +"Treat Every Environment Special (TrEES)");
        System.out.println("=======================================");
        System.out.print("Choose the NGO to donate: ");
        String ngo=sc.nextLine();
        
        double donate= amt*90.0/100;
        int plusPoint= (int)amt*10;
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("Donations.txt",true))) {
            writer.write(username+" has donated $" + donate+" to "+ngo);
            writer.newLine();
            
        } catch (IOException e) {
            System.err.println("Error saving check-in data: " + e.getMessage());
        }
        
         int cPoint= getCurrentPoint(username);
         int newPoint = cPoint + plusPoint;
         updatePoint(username,newPoint);
        
    }
    
    public static int getCurrentPoint(String username){
       int currentPoints=0;
       try{
           Connection con =DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","");
          String query="SELECT *FROM user WHERE username = ?";
            
                try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                    preparedStatement.setString(1, username);
                    try(ResultSet resultSet = preparedStatement.executeQuery()){
                        if(resultSet.next()){
                            currentPoints = resultSet.getInt("current_point");
                            
                        }
                    }
                }
           
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
       return currentPoints;
   }
    
    
    public static void updatePoint(String username, int newPoint){
       try{
           try(Connection con = DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","")){
               String query= "UPDATE user SET current_point = ? WHERE username=?";
               try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                   preparedStatement.setInt(1,newPoint);
                   preparedStatement.setString(2,username);
                   preparedStatement.executeUpdate();
               }
           }
           System.out.println("Point updated successfully");
           System.out.println("Thank you for your donation, your point updated!");
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
   }
    
}
