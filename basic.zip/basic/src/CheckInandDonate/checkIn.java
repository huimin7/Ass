/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CheckInandDonate;

/**
 *
 * @author Chuimin
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class checkIn {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Username: ");
        String username=sc.nextLine();
        
        checkIn(username);
        
    }
    
    public static void checkIn(String user){
        if(hasCheckedIn(user)){
            System.out.println("You already check-in today.");
        }else{
            userCheckIn(user);
            System.out.println("Success");
            int cPoint= getCurrentPoint(user);
            int newPoint=cPoint +1;
            updatePoint(user,newPoint);
            System.out.println("Check-in successfully, your point updated!");
      
        }
        
    }
    
    public static boolean hasCheckedIn(String username){
        try{
             Connection con =DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","");
             
             Date currentDate=new Date();
             SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd");
             String formattedDate = dateFormat.format(currentDate);
             
           
            String selectQuery ="SELECT last_check_in FROM user WHERE username= ?"; 
            
            try(PreparedStatement preparedStatement =con.prepareStatement(selectQuery)){
                
                   preparedStatement.setString(1,username);
                   
                  try(ResultSet resultSet = preparedStatement.executeQuery()){
                      if(resultSet.next()){
                          Date lastCheckinDate = resultSet.getDate("last_check_in");
                          String lastDate = dateFormat.format(lastCheckinDate);
                          System.out.println("Last Check-In Date: "+lastCheckinDate);
                          System.out.println("Current Date: "+ formattedDate);
                         
                          return (lastDate.equals(formattedDate));
                              
                          
                      }
                          
                  }
            
            }
        }catch(SQLException e){
            System.out.println(e.getMessage());
            
        }
        return false;
    }
    
    public static void userCheckIn(String username){
        try{
             try(Connection con = DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","")){
                 Date currentDate = new Date(); 
                 java.sql.Date sqlCurrentDate=new java.sql.Date(currentDate.getTime());
                 String insertQuery = "UPDATE user SET last_check_in =? WHERE username =?";
                 try(PreparedStatement preparedStatement = con.prepareStatement(insertQuery)){
                     preparedStatement.setDate(1,sqlCurrentDate);
                     preparedStatement.setString(2, username);
                     preparedStatement.executeUpdate();
                     
                 }
                
             }
        }catch(Exception e){
            System.out.println(e.getMessage());        }
        
    }
    
    
     public static int getCurrentPoint(String username){
       int currentPoints=0;
       try{
           Connection con =DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","");
          String query="SELECT *FROM user WHERE username = ?";
            
                try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                    preparedStatement.setString(1, username);
                    try(ResultSet resultSet = preparedStatement.executeQuery()){
                        if(resultSet.next()){
                            currentPoints = resultSet.getInt("current_point");
                            
                        }
                    }
                }
           
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
       return currentPoints;
   }
     
     public static void updatePoint(String username, int newPoint){
       try{
           try(Connection con = DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","")){
               String query= "UPDATE user SET current_point = ? WHERE username=?";
               try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                   preparedStatement.setInt(1,newPoint);
                   preparedStatement.setString(2,username);
                   preparedStatement.executeUpdate();
               }
           }
           System.out.println("Point updated successfully");
           
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
   }
          
    
}
