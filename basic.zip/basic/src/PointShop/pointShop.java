/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chuimin
 */
package PointShop;

import java.io.*;
import java.sql.*;
import java.util.*;


public class pointShop {
    public static void main(String[] args) {
        
        Scanner sc= new Scanner(System.in);
        
        String username;
        int choice;
        
        System.out.print("Enter username: ");
        username=sc.nextLine();
        
        System.out.println("Please choose the product you want to redeem.");
            System.out.println("1.Nature-caring merchandise(300 point for each merchandise)\n2.Plant a tree with your name(300 point for 1 tree)");
            choice=sc.nextInt();
            sc.nextLine();
            System.out.println();
            
        switch(choice){
                case 1: {
                    Merchandise(username);
                    break;
                }
                case 2:{
                    plantTree(username);
                    break;
                }
                default:
                    System.out.println("Invalid number. Please enter either 1 or 2");
        
        }
    }
    
    public static void Merchandise(String username){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter MerchandiseID want to purchase: ");
        String id =sc.nextLine();
            
        System.out.print("Enter the number of purchases: ");
        int num = sc.nextInt();
        sc.nextLine();
            
        System.out.print("Enter delivery address: ");
        String add =sc.nextLine();
        
        int cPoint=getCurrentPoint(username);
        
        if(cPoint >= (300*num)){
            int newPoint =cPoint -(num*300);
            updatePoint(username,newPoint);
            try (FileWriter Writer = new FileWriter("MerchandiseOrder.txt",true)){ 
                                Writer.write(username+" orders " + num +" " + id + " to "+ add+ "\n");
                                Writer.close();
                                System.out.println("Order successfully made. Your point updated.\nCurrent point: "+getCurrentPoint(username));
                                
            }catch(IOException e){
                System.out.println(e.getMessage());
            }
            
        }else{
            System.out.println("You have no enough point");
        }
        
    }
    
    public static void plantTree(String username){
        Scanner sc=new Scanner(System.in);
        try{
           
            Connection con= DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","");
            
            
            String query="SELECT *FROM user WHERE username = ?";
            
            try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                preparedStatement.setString(1,username);
                ResultSet resultSet = preparedStatement.executeQuery();
                
                if(resultSet.next()){
                    
                    int cPoint;
                    cPoint = Integer.parseInt(resultSet.getString("current_point"));
                    
                    if(cPoint>=300){
                        System.out.print("Please enter Tree name: ");
                        String TreeName=sc.nextLine();
                        if("".equals(TreeName)||"".equals(username)){
                            System.out.println("Please fill in all the require part");
                            
                
                        }else{
                            try(FileWriter writer =new FileWriter("TreePlantOrder.txt",true)){
                            writer.write(username + " plants a tree with the name "+"\""+ TreeName +"\"\n");
                            writer.close();
                            int newPoint=cPoint-300;
                            
                            updatePoint(username,newPoint);

                        }
                        }
                    }else{
                        System.out.println("You have no enough point.");
                        
                    }
                
                }else{
                    System.out.println("Please enter correct username");
                    
                    
                }
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    
    public static void updatePoint(String username, int newPoint){
       try{
           try(Connection con = DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","")){
               String query= "UPDATE user SET current_point = ? WHERE username=?";
               try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                   preparedStatement.setInt(1,newPoint);
                   preparedStatement.setString(2,username);
                   preparedStatement.executeUpdate();
               }
           }
           System.out.println("Point updated successfully");
           System.out.println("Tree successfully plant, your current point: "+getCurrentPoint(username));
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
   }
    
    
    
    public static int getCurrentPoint(String username){
       int currentPoints=0;
       try{
           Connection con =DriverManager.getConnection("jdbc:MySQL://localhost:3308/user","root","");
          String query="SELECT *FROM user WHERE username = ?";
            
                try(PreparedStatement preparedStatement = con.prepareStatement(query)){
                    preparedStatement.setString(1, username);
                    try(ResultSet resultSet = preparedStatement.executeQuery()){
                        if(resultSet.next()){
                            currentPoints = resultSet.getInt("current_point");
                            
                        }
                    }
                }
           
       }catch(Exception e){
           System.out.println(e.getMessage());
       }
       return currentPoints;
   }
    
    
}
